package com.hello.myapplication.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.LinearProgressIndicator

data class Stop(val name: String, val distanceInKm: Double) {
    val distanceInMiles: Double
        get() = distanceInKm * 0.621371
}

@Composable
fun JourneyApp() {
    var stops by remember { mutableStateOf(listOf(
        Stop("Delhi", 0.0),
        Stop("Agra", 216.2),
        Stop("Jaipur", 238.1),
        Stop("Udaipur", 393.4),
        Stop("Mumbai", 753.6),
        Stop("Pune", 148.0),
        Stop("Hyderabad", 560.2),
        Stop("Bengaluru", 569.9),
        Stop("Chennai", 346.7),
        Stop("Kolkata", 1669.8),
    )) }
    var currentUnit by remember { mutableStateOf("KM") }
    var currentStop by remember { mutableIntStateOf(0) }

    Column(modifier = Modifier.padding(16.dp)) {
        Button(onClick = { currentUnit = if (currentUnit == "KM") "Miles" else "KM" }) {
            Text(text = "Switch to ${if (currentUnit == "KM") "Miles" else "KM"}")
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(onClick = { if (currentStop < stops.size - 1) currentStop++ }) {
            Text(text = "Next Stop")
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(text = "Current Stop: ${stops.getOrNull(currentStop)?.name ?: "N/A"}")

        Spacer(modifier = Modifier.height(8.dp))

        val totalDistance = stops.sumOf { if (currentUnit == "KM") it.distanceInKm else it.distanceInMiles }
        val distanceCovered = stops.subList(0, currentStop + 1).sumOf { if (currentUnit == "KM") it.distanceInKm else it.distanceInMiles }
        val distanceLeft = totalDistance - distanceCovered

        Text(text = "Distance Covered: $distanceCovered $currentUnit")

        Spacer(modifier = Modifier.height(8.dp))

        Text(text = "Distance Left: $distanceLeft $currentUnit")

        Spacer(modifier = Modifier.height(8.dp))

        LinearProgressIndicator(progress = distanceCovered.toFloat() / totalDistance.toFloat())

        Spacer(modifier = Modifier.height(8.dp))

        // Normal list for the first two stops
        Box(modifier = Modifier.background(Color.LightGray)) {
            Column {
                stops.take(2).forEach { stop ->
                    Text(text = "${stop.name}: ${if (currentUnit == "KM") stop.distanceInKm else stop.distanceInMiles} $currentUnit")
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Lazy list for all stops
        Box(modifier = Modifier.background(Color.White)) {
            LazyColumn(modifier = Modifier.height(100.dp)) {
                itemsIndexed(stops) { index, stop ->
                    Text(
                        text = "${stop.name}: ${if (currentUnit == "KM") stop.distanceInKm else stop.distanceInMiles} $currentUnit",
                        color = if (index <= currentStop) Color.Green else Color.Gray
                    )
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    JourneyApp()
}
